// Inlines the Vite build (CSS, JS, fonts) into a single artifact.html.
import { readFileSync, writeFileSync, readdirSync } from 'node:fs'
const dir = 'dist/assets/'
const files = readdirSync(dir)
let css = readFileSync(dir + files.find((f) => f.endsWith('.css')), 'utf8')
for (const f of files.filter((f) => f.endsWith('.woff2'))) {
  const uri = 'data:font/woff2;base64,' + readFileSync(dir + f).toString('base64')
  css = css.split(`/assets/${f}`).join(uri)
}
const js = readFileSync(dir + files.find((f) => f.endsWith('.js')), 'utf8').replace(/<\/script/gi, '<\\/script')
const html = `<title>GOLDEN MANGO</title>
<meta name="description" content="Golden, juicy, ridiculously delicious mangoes. Handpicked for the moments that taste like sunshine.">
<style>${css}</style>
<div id="root"></div>
<script type="module">${js}</script>
`
writeFileSync('artifact.html', html)
console.log('artifact.html', (html.length / 1024).toFixed(0) + ' KB', css.includes('/assets/') ? 'UNRESOLVED ASSET' : 'ok')
