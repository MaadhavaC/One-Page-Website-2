import { useState } from 'react'
import { CartProvider } from './context/CartContext'
import Header, { AnnouncementBar } from './components/Header'
import Hero, { Marquee } from './components/Hero'
import Products from './components/Products'
import Story from './components/Story'
import Lifestyle from './components/Lifestyle'
import Trust from './components/Trust'
import Reviews from './components/Reviews'
import FinalCTA from './components/FinalCTA'
import Newsletter from './components/Newsletter'
import Footer from './components/Footer'
import CartDrawer from './components/CartDrawer'
import Toast from './components/Toast'
import PolicyDialog from './components/PolicyDialog'

export default function App() {
  const [policy, setPolicy] = useState(null)
  return (
    <CartProvider>
      <a href="#main" className="skip-link">Skip to content</a>
      <AnnouncementBar />
      <Header />
      <main id="main">
        <Hero />
        <Marquee />
        <Products />
        <Story />
        <Lifestyle />
        <Trust />
        <Reviews />
        <FinalCTA />
        <Newsletter onOpenPolicy={setPolicy} />
      </main>
      <Footer onOpenPolicy={setPolicy} />
      <CartDrawer />
      <Toast />
      <PolicyDialog policy={policy} onClose={() => setPolicy(null)} />
    </CartProvider>
  )
}
