// Editable page copy for the trust, review and pillar sections.

export const pillars = [
  { icon: 'flavour', title: 'Full of Flavour', text: 'Deliciously sweet, juicy fruit.' },
  { icon: 'care', title: 'Picked with Care', text: 'Quality comes first.' },
  { icon: 'sun', title: 'Sunshine in Every Box', text: 'A little happiness delivered to your door.' },
]

// PLACEHOLDER promises – only keep what the business can genuinely fulfil.
export const trust = [
  { icon: 'select', title: 'Carefully selected fruit', text: 'Every mango is chosen with care before it is packed for you.' },
  { icon: 'lock', title: 'Secure checkout', text: 'Pay through a trusted, encrypted payment provider once checkout is connected.' },
  { icon: 'truck', title: 'Convenient delivery', text: 'Delivery options are shown at checkout. Areas and timings to be confirmed.' },
  { icon: 'support', title: 'Freshness & quality support', text: 'Not happy with your fruit? Get in touch and we will make it right. Policy to be confirmed.' },
]

// SAMPLE content – replace with genuine customer reviews before launch.
export const reviews = [
  { name: 'Amara', stars: 5, text: 'Sample review: The kind of mango that makes you go quiet for a second. Sweet, juicy and gone far too quickly.' },
  { name: 'Josh', stars: 5, text: 'Sample review: Ordered a box to share and ended up hiding half of it. The packaging looked lovely, too.' },
  { name: 'Priya', stars: 4, text: 'Sample review: Fragrant and so tasty. Perfect on a warm afternoon with nothing but a spoon.' },
]

export const lifestyle = [
  { slot: 'lifestylePlate', caption: 'Slice into sunshine', alt: 'Fresh mango slices fanned out on a plate' },
  { slot: 'lifestyleSmoothie', caption: 'Blend your happy place', alt: 'A glass of mango smoothie with a straw in warm sunlight' },
  { slot: 'lifestyleBowl', caption: 'Make every bite count', alt: 'A tropical bowl topped with diced mango, coconut and mint' },
]
