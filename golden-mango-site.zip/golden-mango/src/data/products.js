// Product catalogue – PLACEHOLDER prices/weights, edit freely.
// `price` is in pence (integer) to avoid floating-point errors.
// `variantId` (Shopify) and `stripePriceId` are ready for commerce integration.

export const products = [
  {
    id: 'golden-classic',
    sku: 'GM-CLASSIC',
    name: 'The Golden Classic',
    art: 'classic',
    badge: 'BESTSELLER',
    description: 'Sweet, smooth, and beautifully juicy. A sunshine-filled everyday favourite.',
    price: 250,
    unit: 'per mango',
    size: 'Single mango · approx. 350g',
    imageAlt: 'A glossy golden mango with water droplets on its skin',
    variantId: null,
    stripePriceId: null,
  },
  {
    id: 'tropical-treasure',
    sku: 'GM-TROPICAL',
    name: 'The Tropical Treasure',
    art: 'tropical',
    badge: 'FRAGRANT FAVOURITE',
    description: 'Rich, fragrant, and bursting with exotic flavour.',
    price: 320,
    unit: 'per mango',
    size: 'Single mango · approx. 400g',
    imageAlt: 'Two blush-skinned tropical mangoes and a sliced mango half',
    variantId: null,
    stripePriceId: null,
  },
  {
    id: 'mango-box',
    sku: 'GM-BOX6',
    name: 'The Mango Box',
    art: 'box',
    badge: 'PERFECT FOR SHARING',
    description: 'A handpicked selection for sharing, gifting, or keeping all to yourself.',
    price: 1800,
    unit: 'per box',
    size: 'Box of 6 mangoes · approx. 2kg',
    imageAlt: 'An open kraft box packed with six golden mangoes and green leaves',
    variantId: null,
    stripePriceId: null,
  },
]

export const getProduct = (id) => products.find((p) => p.id === id)
