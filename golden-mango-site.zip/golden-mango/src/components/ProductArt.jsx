import { site } from '../config/site'
import { Photo, PRODUCT_SCENES } from './art/Scenes'

export default function ProductArt({ product, eager = false }) {
  const Scene = PRODUCT_SCENES[product.art]
  return (
    <Photo src={site.images[product.art]} alt={product.imageAlt} eager={eager}>
      <Scene />
    </Photo>
  )
}
