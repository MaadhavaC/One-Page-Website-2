import { site } from '../config/site'
import { HeroScene, Photo } from './art/Scenes'
import { ArrowIcon } from './Icons'
import { Sparkle } from './art/Primitives'
import { useParallax } from '../hooks/useParallax'

export default function Hero() {
  useParallax()
  return (
    <section id="top" aria-labelledby="hero-title" className="relative overflow-hidden bg-ivory">
      <div className="pointer-events-none absolute -left-40 top-20 h-[34rem] w-[34rem] rounded-full bg-cream blur-3xl" aria-hidden="true" />
      <div className="relative mx-auto grid max-w-7xl items-center gap-8 px-4 pb-16 pt-8 sm:px-8 lg:min-h-[calc(100svh-104px)] lg:grid-cols-12 lg:gap-0 lg:pb-14 lg:pt-6">
        <div className="relative z-10 lg:col-span-7">
          <p className="mb-5 inline-flex items-center gap-2 rounded-full bg-cream px-4 py-2 text-xs font-bold uppercase tracking-[.2em] text-leaf animate-[fadeUp_.8s_.1s_both]">
            <Sparkle className="h-3.5 w-3.5 text-flame" /> Picked with care. Packed with love.
          </p>
          <h1 id="hero-title" className="font-serif font-black uppercase leading-[.88] tracking-[-.025em] [word-spacing:.1em] text-leaf text-[clamp(2.9rem,12.4vw,5.2rem)] lg:text-[clamp(4.6rem,7.5vw,8.6rem)] animate-[fadeUp_.9s_.2s_both]">
            A little<br />taste of<br /><em className="font-black not-italic text-flame [text-shadow:0_2px_0_rgba(255,194,26,.6)]">paradise.</em>
          </h1>
          <p className="mt-6 max-w-md text-lg leading-relaxed text-leaf/85 sm:text-xl animate-[fadeUp_.9s_.4s_both]">
            Golden, juicy, ridiculously delicious mangoes. Handpicked for the moments that taste like sunshine.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-x-8 gap-y-4 animate-[fadeUp_.9s_.55s_both]">
            <a href="#shop" className="btn btn-primary">Shop mangoes <ArrowIcon className="btn-arrow h-5 w-5" /></a>
            <a href="#story" className="link-underline rounded py-2 text-base font-semibold text-leaf">Discover our story</a>
          </div>
        </div>
        <div className="relative lg:col-span-5 lg:-ml-10 animate-[fadeIn_1.2s_.3s_both]">
          <Photo src={site.images.hero} alt="Ripe golden mangoes, one cut into glossy cubes, with fresh slices and green leaves on a sunny yellow arch" eager>
            <HeroScene />
          </Photo>
        </div>
      </div>
    </section>
  )
}

export function Marquee() {
  const words = ['Golden', 'Juicy', 'Sun-ripe', 'Handpicked', 'Sweet', 'Fragrant', 'Delicious']
  const row = (hide) => (
    <ul className="flex shrink-0 items-center gap-10 pr-10" aria-hidden={hide || undefined}>
      {words.map((w) => (
        <li key={w} className="flex items-center gap-10 font-serif text-2xl font-black uppercase tracking-wide text-leaf sm:text-3xl">
          {w} <Sparkle className="h-5 w-5 text-leaf/70" />
        </li>
      ))}
    </ul>
  )
  return (
    <div className="overflow-hidden bg-sun py-4" role="presentation">
      <div className="flex w-max animate-marquee">{row(false)}{row(true)}</div>
    </div>
  )
}
