import { useId, useMemo } from 'react'
import { Mango, Cheek, Slice, Leaf, rng } from './Primitives'

/** Wraps a scene in either a configured photo or the built-in artwork. */
export function Photo({ src, alt, eager = false, className = '', children }) {
  if (src) {
    return (
      <img src={src} alt={alt} loading={eager ? 'eager' : 'lazy'} decoding="async" fetchPriority={eager ? 'high' : 'auto'} className={`h-full w-full object-cover ${className}`} />
    )
  }
  return <div role="img" aria-label={alt} className={`h-full w-full ${className}`}>{children}</div>
}

/* ───────── Products ───────── */

export function ClassicScene() {
  return (
    <div className="relative h-full w-full overflow-hidden bg-[#FFE9A6]">
      <div className="absolute -right-[18%] -top-[12%] h-[70%] w-[90%] rounded-full bg-[#FFD54A]/70" />
      <Leaf className="absolute -left-[4%] bottom-[2%] h-[62%] -rotate-[28deg] opacity-95" />
      <Leaf className="absolute right-[2%] bottom-[0%] h-[46%] rotate-[34deg]" tone="light" />
      <Mango variant="golden" seed={3} className="absolute left-1/2 top-[8%] h-[84%] -translate-x-1/2 rotate-[8deg] drop-shadow-xl" />
    </div>
  )
}

export function TropicalScene() {
  return (
    <div className="relative h-full w-full overflow-hidden bg-[#DDEBB8]">
      <div className="absolute -left-[20%] top-[18%] h-[75%] w-[95%] rounded-full bg-[#F3E58B]/70" />
      <Leaf className="absolute right-[6%] top-[-6%] h-[56%] rotate-[160deg]" />
      <Leaf className="absolute -left-[2%] bottom-[-6%] h-[52%] -rotate-[40deg]" tone="light" />
      <Mango variant="tropical" seed={9} className="absolute left-[2%] top-[14%] h-[64%] -rotate-[10deg]" />
      <Mango variant="tropical" seed={14} className="absolute right-[0%] top-[34%] h-[52%] rotate-[16deg]" />
      <Cheek seed={5} className="absolute bottom-[3%] left-[14%] h-[34%] w-[56%]" />
    </div>
  )
}

export function BoxScene() {
  const spots = [
    { l: '6%', t: '27%', r: -14, v: 'golden', s: 21 }, { l: '35%', t: '24%', r: 8, v: 'tropical', s: 22 }, { l: '64%', t: '27%', r: 18, v: 'golden', s: 23 },
    { l: '9%', t: '47%', r: 12, v: 'tropical', s: 24 }, { l: '37%', t: '49%', r: -8, v: 'golden', s: 25 }, { l: '65%', t: '47%', r: 4, v: 'tropical', s: 26 },
  ]
  return (
    <div className="relative h-full w-full overflow-hidden bg-[#F6DDB0]">
      <div className="absolute -top-[10%] left-[10%] h-[60%] w-[80%] rounded-full bg-[#FFD54A]/50" />
      <Leaf className="absolute left-[2%] top-[2%] h-[44%] -rotate-[58deg]" />
      <Leaf className="absolute right-[0%] top-[2%] h-[40%] rotate-[56deg]" tone="light" />
      <div className="absolute inset-x-[5%] bottom-[6%] top-[20%] rounded-xl bg-gradient-to-br from-[#5f3d18] to-[#7b4f22] shadow-[0_24px_40px_-12px_rgba(58,33,8,.55)]" />
      {spots.map((m, i) => (
        <Mango key={i} variant={m.v} seed={m.s} drops={false} className="absolute h-[31%] drop-shadow-md" style={{ left: m.l, top: m.t, transform: `rotate(${m.r}deg)` }} />
      ))}
      <div className="absolute inset-x-[5%] bottom-[6%] h-[24%] rounded-b-xl bg-gradient-to-b from-[#C99A5E] to-[#A8763A] shadow-[0_-10px_20px_-6px_rgba(58,33,8,.45)]">
        <div className="mx-auto mt-[6%] flex w-fit items-center gap-2 rounded-full bg-ivory/90 px-4 py-1 font-serif text-[10px] font-bold uppercase tracking-[.2em] text-leaf">Golden Mango</div>
      </div>
    </div>
  )
}

/* ───────── Hero / editorial ───────── */

/** Layer wrapper: outer = mouse/scroll parallax, inner = ambient float. */
const Layer = ({ depth = 10, delay = 0, className = '', children }) => (
  <div className={`plx absolute ${className}`} style={{ '--d': depth }}>
    <div className="float-slow h-full w-full" style={{ animationDelay: `${delay}s` }}>{children}</div>
  </div>
)

export function HeroScene() {
  return (
    <div className="relative mx-auto aspect-[4/5] w-full max-w-[540px] lg:max-w-none" data-parallax>
      <div className="grain absolute inset-x-[7%] bottom-0 top-[3%] overflow-hidden rounded-t-[999px] rounded-b-[2.25rem] bg-sun shadow-[0_40px_80px_-30px_rgba(169,62,8,.55)]">
        <div className="absolute -left-1/4 top-[40%] h-[70%] w-[110%] rounded-full bg-amber/45 blur-2xl" />
      </div>
      <Layer depth={-10} className="left-[0%] top-[24%] h-[44%] w-[17%] -rotate-[22deg]"><Leaf className="h-full w-full" /></Layer>
      <Layer depth={-14} delay={1.2} className="right-[-2%] top-[8%] h-[42%] w-[16%] rotate-[30deg]"><Leaf className="h-full w-full" tone="light" /></Layer>
      <Layer depth={14} className="left-[5%] top-[30%] h-[60%] w-[92%]"><Cheek seed={7} className="h-full w-full drop-shadow-2xl" /></Layer>
      <Layer depth={24} delay={0.6} className="left-[-6%] top-[2%] h-[36%] w-[28%] -rotate-[16deg]"><Mango variant="golden" seed={3} className="h-full w-full drop-shadow-2xl" /></Layer>
      <Layer depth={20} delay={1.8} className="right-[-4%] top-[44%] h-[28%] w-[22%] rotate-[18deg]"><Mango variant="tropical" seed={11} className="h-full w-full drop-shadow-2xl" /></Layer>
      <Layer depth={30} delay={0.9} className="bottom-[3%] left-[2%] h-[12%] w-[30%] -rotate-[14deg]"><Slice className="h-full w-full drop-shadow-xl" /></Layer>
      <Layer depth={34} delay={2.4} className="bottom-[8%] right-[6%] h-[9%] w-[24%] rotate-[10deg]"><Slice className="h-full w-full drop-shadow-xl" /></Layer>
    </div>
  )
}

export function StoryScene() {
  return (
    <div className="relative h-full w-full overflow-hidden bg-[#F3E2B4]">
      <div className="absolute left-[6%] top-[5%] h-[78%] w-[88%] rounded-full bg-[#FFD54A]/60" />
      <Leaf className="absolute right-[4%] top-[2%] h-[48%] rotate-[40deg]" />
      <Leaf className="absolute bottom-[0%] left-[-2%] h-[42%] rotate-[-50deg]" tone="light" />
      <Cheek seed={21} className="absolute left-[4%] top-[28%] h-[56%] w-[84%] drop-shadow-xl" />
      <Mango variant="golden" seed={4} className="absolute right-[4%] top-[6%] h-[46%] rotate-[14deg] drop-shadow-xl" />
      <Slice className="absolute bottom-[3%] right-[8%] h-[10%] -rotate-[8deg] drop-shadow-lg" />
    </div>
  )
}

export function FinaleScene() {
  return (
    <div className="relative h-full w-full">
      <Leaf className="absolute -left-[4%] top-[6%] h-[50%] -rotate-[34deg] opacity-90" />
      <Cheek seed={33} className="absolute left-[2%] top-[8%] h-[88%] w-[100%] drop-shadow-2xl" />
      <Mango variant="tropical" seed={6} className="absolute -right-[2%] bottom-[0%] h-[46%] rotate-[18deg] drop-shadow-xl" />
      <Slice className="absolute left-[4%] bottom-[2%] h-[12%] -rotate-[10deg] drop-shadow-lg" />
    </div>
  )
}

/* ───────── Lifestyle ───────── */

export function PlateScene() {
  const id = useId().replace(/:/g, '')
  return (
    <div className="relative h-full w-full overflow-hidden bg-[#CFE0B0]">
      <div className="absolute -bottom-[20%] -left-[10%] h-[70%] w-[90%] rounded-full bg-[#B7D08A]/70" />
      <Leaf className="absolute right-[2%] top-[-4%] h-[52%] rotate-[28deg]" />
      <Leaf className="absolute left-[-3%] top-[2%] h-[38%] -rotate-[40deg]" tone="light" />
      <svg viewBox="0 0 400 300" className="absolute inset-x-0 bottom-[4%] w-full" aria-hidden="true" focusable="false">
        <defs>
          <radialGradient id={`${id}p`} cx=".4" cy=".35" r=".8"><stop offset="0" stopColor="#FFFDF6" /><stop offset="1" stopColor="#E9E0CB" /></radialGradient>
          <filter id={`${id}b`}><feGaussianBlur stdDeviation="9" /></filter>
        </defs>
        <ellipse cx="200" cy="246" rx="170" ry="26" fill="#2a3a10" opacity=".3" filter={`url(#${id}b)`} />
        <ellipse cx="200" cy="170" rx="176" ry="104" fill={`url(#${id}p)`} />
        <ellipse cx="200" cy="170" rx="132" ry="76" fill="#F4ECD8" stroke="#E2D6BA" strokeWidth="2" />
      </svg>
      <Cheek seed={12} className="absolute left-[15%] top-[41%] w-[70%] origin-center scale-y-[.84] drop-shadow-lg" />
      <Slice className="absolute bottom-[17%] left-[7%] w-[24%] -rotate-[12deg] drop-shadow-md" />
      <Slice className="absolute bottom-[19%] right-[8%] w-[22%] rotate-[10deg] drop-shadow-md" />
    </div>
  )
}

export function SmoothieScene() {
  const id = useId().replace(/:/g, '')
  const beads = useMemo(() => { const r = rng(17); return Array.from({ length: 14 }, () => ({ x: 70 + r() * 100, y: 120 + r() * 190, r: 1.6 + r() * 3 })) }, [])
  return (
    <div className="relative h-full w-full overflow-hidden bg-[#FFC987]">
      <div className="absolute -left-[30%] -top-[10%] h-[120%] w-[70%] -rotate-[24deg] bg-gradient-to-b from-white/50 to-white/0 blur-xl" />
      <div className="absolute -right-[20%] top-[6%] h-[55%] w-[85%] rounded-full bg-[#FFE08A]/80" />
      <Leaf className="absolute -right-[4%] bottom-[2%] h-[44%] rotate-[32deg]" />
      <Mango variant="golden" seed={8} className="absolute bottom-[3%] left-[2%] h-[28%] -rotate-[10deg]" />
      <svg viewBox="0 0 240 380" className="absolute inset-x-[14%] bottom-[2%] h-[92%] w-[72%]" aria-hidden="true" focusable="false">
        <defs>
          <linearGradient id={`${id}l`} x1="0" y1="0" x2="1" y2="0"><stop offset="0" stopColor="#F27A12" /><stop offset=".45" stopColor="#FFB020" /><stop offset="1" stopColor="#F29A1A" /></linearGradient>
          <linearGradient id={`${id}g`} x1="0" y1="0" x2="1" y2="0"><stop offset="0" stopColor="#fff" stopOpacity=".55" /><stop offset=".25" stopColor="#fff" stopOpacity=".08" /><stop offset=".8" stopColor="#fff" stopOpacity=".1" /><stop offset="1" stopColor="#fff" stopOpacity=".4" /></linearGradient>
          <filter id={`${id}b`}><feGaussianBlur stdDeviation="9" /></filter>
          <clipPath id={`${id}c`}><path d="M38 70H202L190 320Q189 346 164 346H76Q51 346 50 320Z" /></clipPath>
        </defs>
        <ellipse cx="124" cy="352" rx="92" ry="12" fill="#5a2a00" opacity=".3" filter={`url(#${id}b)`} />
        <path d="M150 70L196 -6L210 0L164 74Z" fill="#fff" stroke="#1F4A2E" strokeWidth="0" />
        <path d="M156 56L200 -6L210 0L170 66Z" fill="#1F4A2E" opacity=".9" />
        <g clipPath={`url(#${id}c)`}>
          <rect x="30" y="96" width="190" height="260" fill={`url(#${id}l)`} />
          <ellipse cx="120" cy="96" rx="82" ry="12" fill="#FFE9A8" />
          <rect x="30" y="190" width="190" height="10" fill="#fff" opacity=".18" />
        </g>
        <path d="M38 70H202L190 320Q189 346 164 346H76Q51 346 50 320Z" fill={`url(#${id}g)`} stroke="#fff" strokeOpacity=".7" strokeWidth="2.5" />
        <ellipse cx="120" cy="70" rx="82" ry="11" fill="none" stroke="#fff" strokeOpacity=".8" strokeWidth="2.5" />
        <path d="M62 100L70 320" stroke="#fff" strokeOpacity=".7" strokeWidth="6" strokeLinecap="round" />
        {beads.map((b, i) => <circle key={i} cx={b.x} cy={b.y} r={b.r} fill="#fff" opacity=".45" stroke="#fff" strokeOpacity=".7" strokeWidth=".6" />)}
        <g transform="translate(150 54) rotate(-12)">
          <path d="M-8 0C20 44 74 44 100 0C74 22 20 22 -8 0Z" fill="#FFB52E" />
          <path d="M-8 0C20 44 74 44 100 0" stroke="#F0861E" strokeWidth="6" strokeLinecap="round" fill="none" />
        </g>
      </svg>
    </div>
  )
}

export function BowlScene() {
  const id = useId().replace(/:/g, '')
  const cubes = useMemo(() => {
    const r = rng(41), out = []
    for (let n = 0; n < 62; n++) {
      const a = r() * Math.PI, d = Math.sqrt(r())
      out.push({ x: 200 + Math.cos(a) * 120 * d * (r() > .5 ? 1 : -1), y: 142 - Math.sin(a) * 52 * d, s: 15 + r() * 7, rot: r() * 60 - 30, t: r() })
    }
    return out.sort((a, b) => a.y - b.y)
  }, [])
  const flakes = useMemo(() => { const r = rng(5); return Array.from({ length: 16 }, () => ({ x: 120 + r() * 160, y: 110 + r() * 40, rot: r() * 180 })) }, [])
  return (
    <div className="relative h-full w-full overflow-hidden bg-[#FFE27A]">
      <div className="absolute -right-[16%] -top-[14%] h-[70%] w-[90%] rounded-full bg-[#FFC21A]/60" />
      <Leaf className="absolute left-[-2%] top-[0%] h-[46%] -rotate-[46deg]" tone="light" />
      <Leaf className="absolute right-[0%] top-[4%] h-[40%] rotate-[48deg]" />
      <svg viewBox="0 0 400 300" className="absolute inset-x-0 bottom-[5%] w-full" aria-hidden="true" focusable="false">
        <defs>
          <linearGradient id={`${id}w`} x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#FFF9EC" /><stop offset="1" stopColor="#E7D8B6" /></linearGradient>
          <radialGradient id={`${id}c`} cx=".3" cy=".25" r=".9"><stop offset="0" stopColor="#FFE47A" /><stop offset=".5" stopColor="#FFB020" /><stop offset="1" stopColor="#F07A10" /></radialGradient>
          <filter id={`${id}b`}><feGaussianBlur stdDeviation="9" /></filter>
        </defs>
        <ellipse cx="200" cy="268" rx="150" ry="16" fill="#5a3a00" opacity=".3" filter={`url(#${id}b)`} />
        <path d="M44 150H356C356 230 300 272 200 272C100 272 44 230 44 150Z" fill={`url(#${id}w)`} />
        <ellipse cx="200" cy="150" rx="156" ry="30" fill="#EADDBF" />
        <ellipse cx="200" cy="150" rx="146" ry="24" fill="#FFF3D6" />
        {cubes.map((c, i) => (
          <g key={i} transform={`translate(${c.x} ${c.y}) rotate(${c.rot})`}>
            <rect x={-c.s / 2} y={-c.s / 2} width={c.s} height={c.s} rx="4" fill={`url(#${id}c)`} />
            <rect x={-c.s / 2 + 2} y={-c.s / 2 + 2} width={c.s * .5} height="2.5" rx="1.2" fill="#fff" opacity=".55" />
          </g>
        ))}
        {flakes.map((f, i) => <path key={i} d="M0 0Q8 -6 14 0Q8 3 0 0Z" transform={`translate(${f.x} ${f.y}) rotate(${f.rot})`} fill="#fff" opacity=".92" />)}
        {[[170, 92, -30], [236, 98, 24], [204, 84, 4]].map(([x, y, r], i) => (
          <path key={i} d="M0 0C10 -18 30 -18 36 0C26 8 8 10 0 0Z" transform={`translate(${x} ${y}) rotate(${r})`} fill="#2F7A3A" stroke="#1F5A2A" strokeWidth="1" />
        ))}
      </svg>
    </div>
  )
}

export const PRODUCT_SCENES = { classic: ClassicScene, tropical: TropicalScene, box: BoxScene }
