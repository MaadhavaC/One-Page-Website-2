import { useId, useMemo } from 'react'

/** Small deterministic PRNG so artwork is identical on every render. */
export const rng = (seed) => {
  let s = seed % 2147483647
  if (s <= 0) s += 2147483646
  return () => (s = (s * 16807) % 2147483647) / 2147483647
}

const PALETTES = {
  golden: { hi: '#FFF08A', mid: '#FFC61F', lo: '#F28A1A', blush: '#F26A2A', green: '#A9BE3B' },
  tropical: { hi: '#FFE06A', mid: '#FFA21F', lo: '#E4501C', blush: '#D8352A', green: '#8DAF35' },
}

const MANGO = 'M96 10C140 2 188 40 192 108C195 170 150 226 100 232C78 234 60 226 42 208C10 176 6 120 22 74C36 36 62 14 96 10Z'

/** A glossy whole mango with water droplets. viewBox 200×260 (origin y = -12). */
export function Mango({ variant = "golden", seed = 3, label, className = "", drops = true, style }) {
  const id = useId().replace(/:/g, '')
  const p = PALETTES[variant]
  const specks = useMemo(() => {
    const r = rng(seed * 97 + 11)
    return Array.from({ length: 56 }, () => ({ x: 20 + r() * 160, y: 20 + r() * 205, r: 0.5 + r() * 1.1, o: 0.12 + r() * 0.28 }))
  }, [seed])
  const dropsList = useMemo(() => {
    const r = rng(seed * 31 + 5)
    return Array.from({ length: 9 }, () => ({ x: 40 + r() * 120, y: 60 + r() * 150, r: 2 + r() * 4.2 }))
  }, [seed])
  return (
    <svg viewBox="0 -12 200 260" className={className} style={style} role={label ? 'img' : undefined} aria-label={label} aria-hidden={label ? undefined : true} focusable="false">
      <defs>
        <radialGradient id={`${id}b`} cx=".34" cy=".3" r=".95">
          <stop offset="0" stopColor={p.hi} /><stop offset=".42" stopColor={p.mid} /><stop offset="1" stopColor={p.lo} />
        </radialGradient>
        <radialGradient id={`${id}r`} cx=".88" cy=".82" r=".75">
          <stop offset="0" stopColor={p.blush} stopOpacity=".85" /><stop offset="1" stopColor={p.blush} stopOpacity="0" />
        </radialGradient>
        <radialGradient id={`${id}g`} cx=".3" cy=".0" r=".6">
          <stop offset="0" stopColor={p.green} stopOpacity=".75" /><stop offset="1" stopColor={p.green} stopOpacity="0" />
        </radialGradient>
        <radialGradient id={`${id}d`}>
          <stop offset=".55" stopColor="#fff" stopOpacity=".08" /><stop offset="1" stopColor="#fff" stopOpacity=".55" />
        </radialGradient>
        <clipPath id={`${id}c`}><path d={MANGO} /></clipPath>
        <filter id={`${id}f`} x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="5" /></filter>
        <filter id={`${id}s`} x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="7" /></filter>
      </defs>
      <ellipse cx="104" cy="236" rx="68" ry="9" fill="#3a2108" opacity=".28" filter={`url(#${id}s)`} />
      <path d={MANGO} fill={`url(#${id}b)`} />
      <g clipPath={`url(#${id}c)`}>
        <path d={MANGO} fill={`url(#${id}r)`} />
        <path d={MANGO} fill={`url(#${id}g)`} />
        {specks.map((s, i) => <circle key={i} cx={s.x} cy={s.y} r={s.r} fill="#fff6c0" opacity={s.o} />)}
        <path d={MANGO} fill="none" stroke={p.lo} strokeWidth="14" opacity=".35" filter={`url(#${id}f)`} />
        <ellipse cx="58" cy="78" rx="11" ry="38" transform="rotate(24 58 78)" fill="#fff" opacity=".6" filter={`url(#${id}f)`} />
        <ellipse cx="52" cy="62" rx="4" ry="18" transform="rotate(24 52 62)" fill="#fff" opacity=".85" />
        <ellipse cx="150" cy="190" rx="22" ry="8" transform="rotate(-38 150 190)" fill="#fff" opacity=".22" filter={`url(#${id}f)`} />
      </g>
      <ellipse cx="98" cy="14" rx="15" ry="5.5" fill="#3d3a12" opacity=".35" />
      <path d="M97 14C95 4 102 -4 114 -5" stroke="#5a3a1a" strokeWidth="5.5" strokeLinecap="round" fill="none" />
      {drops && dropsList.map((d, i) => (
        <g key={i}>
          <circle cx={d.x + 1.2} cy={d.y + 1.8} r={d.r} fill="#7a3a00" opacity=".18" />
          <circle cx={d.x} cy={d.y} r={d.r} fill={`url(#${id}d)`} stroke="#fff" strokeOpacity=".7" strokeWidth=".6" />
          <circle cx={d.x - d.r * 0.35} cy={d.y - d.r * 0.4} r={d.r * 0.28} fill="#fff" />
        </g>
      ))}
    </svg>
  )
}

/** A mango cut into a glossy "hedgehog" cheek. viewBox 320×300. */
export function Cheek({ label, className = '', seed = 7 }) {
  const id = useId().replace(/:/g, '')
  const cells = useMemo(() => {
    const S = 23, out = []
    const r = rng(seed)
    for (let i = -8; i <= 8; i++) for (let j = -8; j <= 8; j++) {
      const x = (i - j) * S / Math.SQRT2, y = (i + j) * S / Math.SQRT2
      const d2 = (x / 124) ** 2 + (y / 100) ** 2
      if (d2 > 0.82) continue
      out.push({ x: 160 + x * (1 + 0.1 * d2), y: 150 + y * (1 + 0.1 * d2), h: S * 0.47 * (1.08 - 0.18 * d2), d2, o: r() })
    }
    return out
  }, [seed])
  const drops = useMemo(() => {
    const r = rng(seed * 13)
    return Array.from({ length: 8 }, () => ({ x: 70 + r() * 180, y: 60 + r() * 170, r: 2.5 + r() * 4 }))
  }, [seed])
  return (
    <svg viewBox="0 0 320 300" className={className} role={label ? 'img' : undefined} aria-label={label} aria-hidden={label ? undefined : true} focusable="false">
      <defs>
        <linearGradient id={`${id}k`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#9DB83A" /><stop offset=".45" stopColor="#F4C020" /><stop offset="1" stopColor="#EE6A1E" />
        </linearGradient>
        <radialGradient id={`${id}f`} cx=".4" cy=".35" r=".8">
          <stop offset="0" stopColor="#FFC93C" /><stop offset=".7" stopColor="#F59A14" /><stop offset="1" stopColor="#D8650A" />
        </radialGradient>
        <radialGradient id={`${id}c`} cx=".3" cy=".22" r=".85">
          <stop offset="0" stopColor="#FFE47A" /><stop offset=".45" stopColor="#FFB020" /><stop offset="1" stopColor="#F07A10" />
        </radialGradient>
        <radialGradient id={`${id}d`}>
          <stop offset=".55" stopColor="#fff" stopOpacity=".1" /><stop offset="1" stopColor="#fff" stopOpacity=".6" />
        </radialGradient>
        <filter id={`${id}b`} x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="7" /></filter>
      </defs>
      <ellipse cx="170" cy="272" rx="125" ry="14" fill="#3a2108" opacity=".3" filter={`url(#${id}b)`} />
      <ellipse cx="160" cy="150" rx="150" ry="124" fill={`url(#${id}k)`} />
      <ellipse cx="160" cy="150" rx="136" ry="110" fill={`url(#${id}f)`} />
      <ellipse cx="160" cy="152" rx="130" ry="104" fill="#C95A08" opacity=".5" />
      {cells.map((c, i) => (
        <g key={i} transform={`translate(${c.x.toFixed(1)} ${c.y.toFixed(1)}) rotate(45)`}>
          <rect x={-c.h} y={-c.h} width={c.h * 2} height={c.h * 2} rx={c.h * 0.38} fill={`url(#${id}c)`} />
          {c.d2 > 0.35 && <rect x={-c.h} y={-c.h} width={c.h * 2} height={c.h * 2} rx={c.h * 0.38} fill="#B8480A" opacity={(c.d2 - 0.3) * 0.5} />}
          <ellipse cx={-c.h * 0.3} cy={-c.h * 0.42} rx={c.h * 0.42} ry={c.h * 0.16} fill="#fff" opacity={0.35 + c.o * 0.3} />
        </g>
      ))}
      <path d="M44 120C60 66 112 38 168 36" stroke="#fff" strokeOpacity=".5" strokeWidth="5" strokeLinecap="round" fill="none" filter={`url(#${id}b)`} />
      {drops.map((d, i) => (
        <g key={i}>
          <circle cx={d.x + 1.5} cy={d.y + 2} r={d.r} fill="#7a3a00" opacity=".2" />
          <circle cx={d.x} cy={d.y} r={d.r} fill={`url(#${id}d)`} stroke="#fff" strokeOpacity=".75" strokeWidth=".7" />
          <circle cx={d.x - d.r * 0.35} cy={d.y - d.r * 0.4} r={d.r * 0.28} fill="#fff" />
        </g>
      ))}
    </svg>
  )
}

/** A crescent mango slice with a skin edge. viewBox 150×70. */
export function Slice({ className = '', label }) {
  const id = useId().replace(/:/g, '')
  return (
    <svg viewBox="0 0 150 70" className={className} role={label ? 'img' : undefined} aria-label={label} aria-hidden={label ? undefined : true} focusable="false">
      <defs>
        <linearGradient id={`${id}f`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#FFD35A" /><stop offset="1" stopColor="#FF9E1F" />
        </linearGradient>
        <linearGradient id={`${id}s`} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#A9BE3B" /><stop offset=".5" stopColor="#F6B81E" /><stop offset="1" stopColor="#EE7A1E" />
        </linearGradient>
      </defs>
      <path d="M6 8C42 70 108 70 144 8C106 38 44 38 6 8Z" fill={`url(#${id}f)`} />
      <path d="M6 8C42 70 108 70 144 8" stroke={`url(#${id}s)`} strokeWidth="6" strokeLinecap="round" fill="none" />
      <path d="M26 20C56 44 96 44 126 20" stroke="#fff" strokeOpacity=".5" strokeWidth="2.2" strokeLinecap="round" fill="none" />
    </svg>
  )
}

/** A mango leaf. viewBox 120×300. */
export function Leaf({ className = '', tone = 'leaf' }) {
  const id = useId().replace(/:/g, '')
  const [a, b] = tone === 'light' ? ['#6E9A3C', '#3F7A32'] : ['#2F6B3E', '#123A22']
  const veins = Array.from({ length: 11 }, (_, i) => 40 + i * 21)
  return (
    <svg viewBox="0 0 120 300" className={className} aria-hidden="true" focusable="false">
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor={a} /><stop offset="1" stopColor={b} /></linearGradient>
      </defs>
      <path d="M60 0C104 62 108 196 60 300C12 196 16 62 60 0Z" fill={`url(#${id})`} />
      <path d="M60 6V296" stroke="#d6e8a8" strokeOpacity=".55" strokeWidth="2.2" />
      {veins.map((y) => (
        <g key={y} stroke="#d6e8a8" strokeOpacity=".28" strokeWidth="1.2" fill="none">
          <path d={`M60 ${y}Q80 ${y - 6} ${60 + 34 * Math.sin((y / 300) * Math.PI)} ${y - 22}`} />
          <path d={`M60 ${y}Q40 ${y - 6} ${60 - 34 * Math.sin((y / 300) * Math.PI)} ${y - 22}`} />
        </g>
      ))}
      <path d="M40 60C34 110 36 170 56 250" stroke="#fff" strokeOpacity=".16" strokeWidth="6" strokeLinecap="round" fill="none" />
    </svg>
  )
}

export function Sparkle({ className = '' }) {
  return (
    <svg viewBox="0 0 40 40" className={className} aria-hidden="true" focusable="false">
      <path d="M20 0C21 12 28 19 40 20C28 21 21 28 20 40C19 28 12 21 0 20C12 19 19 12 20 0Z" fill="currentColor" />
    </svg>
  )
}
