import { site } from '../config/site'
import { FinaleScene, Photo } from './art/Scenes'
import { ArrowIcon } from './Icons'
import Reveal from './Reveal'

export default function FinalCTA() {
  return (
    <section aria-labelledby="cta-title" className="grain relative overflow-hidden bg-sun px-4 py-20 sm:px-8 sm:py-28">
      <div className="mx-auto grid max-w-7xl items-center gap-10 lg:grid-cols-12">
        <Reveal className="relative z-10 lg:col-span-7">
          <h2 id="cta-title" className="font-serif font-black uppercase leading-[.9] tracking-[-.02em] text-leaf text-[clamp(2.6rem,10.5vw,4.6rem)] lg:text-[clamp(4rem,6.6vw,7.4rem)]">
            Your mango moment starts here.
          </h2>
          <p className="mt-6 text-xl font-medium text-leaf sm:text-2xl">Go on. Make today a little sweeter.</p>
          <a href="#shop" className="btn btn-dark mt-9">Get your mango fix <ArrowIcon className="btn-arrow h-5 w-5" /></a>
        </Reveal>
        <Reveal delay={150} className="lg:col-span-5">
          <div className="mx-auto aspect-square w-full max-w-md lg:max-w-none">
            <Photo src={site.images.finale} alt="Close-up of a golden mango cut into glossy juicy cubes"><FinaleScene /></Photo>
          </div>
        </Reveal>
      </div>
    </section>
  )
}
