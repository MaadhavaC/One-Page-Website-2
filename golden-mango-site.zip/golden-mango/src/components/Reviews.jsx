import { reviews } from '../data/content'
import { Star } from './Icons'
import Reveal from './Reveal'

export default function Reviews() {
  return (
    <section aria-labelledby="reviews-title" className="bg-cream px-4 py-20 sm:px-8 sm:py-28">
      <div className="mx-auto max-w-7xl">
        <Reveal className="mx-auto max-w-3xl text-center">
          <p className="eyebrow">Reviews</p>
          <h2 id="reviews-title" className="h-display">Don't just take our word <em className="text-flame not-italic">for it.</em></h2>
          <p className="mx-auto mt-5 inline-block rounded-full border border-dashed border-leaf/40 px-4 py-1.5 text-sm font-medium text-leaf/80">
            Sample reviews shown as placeholders until genuine customer reviews are added.
          </p>
        </Reveal>
        <ul className="mt-14 grid gap-6 md:grid-cols-3">
          {reviews.map((r, i) => (
            <Reveal as="li" key={r.name} delay={i * 120} className={i === 1 ? 'md:mt-8' : ''}>
              <figure className="flex h-full flex-col rounded-[2rem] bg-ivory p-7 shadow-[0_24px_50px_-32px_rgba(31,74,46,.45)]">
                <div role="img" aria-label={`${r.stars} out of 5 stars`} className="flex gap-1">
                  {[1, 2, 3, 4, 5].map((n) => <Star key={n} filled={n <= r.stars} className="h-6 w-6" />)}
                </div>
                <blockquote className="mt-4 flex-1 font-serif text-xl leading-snug text-leaf">“{r.text}”</blockquote>
                <figcaption className="mt-6 flex items-center gap-3 text-sm font-semibold text-leaf">
                  <span aria-hidden="true" className="grid h-10 w-10 place-items-center rounded-full bg-sun font-serif text-lg font-black">{r.name[0]}</span>
                  {r.name}
                  <span className="ml-auto rounded-full bg-cream px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest text-earth">Sample</span>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </ul>
      </div>
    </section>
  )
}
