import { MinusIcon, PlusIcon } from './Icons'

/** Accessible quantity stepper (1–99). */
export default function Quantity({ value, onChange, label, min = 1, compact = false, onBelowMin }) {
  const clamp = (n) => Math.max(min, Math.min(99, n))
  const dec = () => (value - 1 < min && onBelowMin ? onBelowMin() : onChange(clamp(value - 1)))
  const size = compact ? 'h-8 w-8' : 'h-11 w-11'
  const btn = `${size} grid place-items-center rounded-full text-leaf transition hover:bg-leaf hover:text-ivory disabled:opacity-35 disabled:hover:bg-transparent disabled:hover:text-leaf`
  return (
    <div role="group" aria-label={`Quantity for ${label}`} className="inline-flex items-center rounded-full border border-leaf/25 bg-ivory p-0.5">
      <button type="button" className={btn} onClick={dec} disabled={!onBelowMin && value <= min} aria-label={`Decrease quantity of ${label}`}>
        <MinusIcon className="h-4 w-4" />
      </button>
      <input
        type="number" inputMode="numeric" min={min} max={99} value={value}
        onChange={(e) => { const n = parseInt(e.target.value, 10); if (!Number.isNaN(n)) onChange(clamp(n)) }}
        aria-label={`${label} quantity`}
        className={`${compact ? 'w-9 text-sm' : 'w-11 text-base'} bg-transparent text-center font-semibold tabular-nums text-leaf [appearance:textfield] focus-visible:outline-none [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none`}
      />
      <button type="button" className={btn} onClick={() => onChange(clamp(value + 1))} disabled={value >= 99} aria-label={`Increase quantity of ${label}`}>
        <PlusIcon className="h-4 w-4" />
      </button>
    </div>
  )
}
