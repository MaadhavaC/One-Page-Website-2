import { site } from '../config/site'
import { pillars } from '../data/content'
import { Photo, StoryScene } from './art/Scenes'
import { FeatureIcon } from './Icons'
import Reveal from './Reveal'

export default function Story() {
  return (
    <section id="story" aria-labelledby="story-title" className="scroll-mt-16 overflow-hidden bg-ivory px-4 py-20 sm:px-8 sm:py-28">
      <div className="mx-auto grid max-w-7xl items-center gap-12 lg:grid-cols-12 lg:gap-16">
        <Reveal className="lg:col-span-6">
          <div className="relative mx-auto aspect-[5/6] max-w-xl overflow-hidden rounded-t-[999px] rounded-b-[2rem] shadow-[0_40px_70px_-35px_rgba(31,74,46,.55)] lg:max-w-none">
            <Photo src={site.images.story} alt="A mango cut into golden cubes beside a whole mango, a fresh slice and green leaves">
              <StoryScene />
            </Photo>
          </div>
        </Reveal>
        <div className="lg:col-span-6 lg:pl-6">
          <Reveal>
            <p className="eyebrow">Our story</p>
            <h2 id="story-title" className="h-display">Not just mangoes. Little moments of <em className="text-flame not-italic">happiness.</em></h2>
            <p className="mt-6 max-w-xl text-lg leading-relaxed text-leaf/85 sm:text-xl">
              We believe the best things in life are simple. The first bite of a perfectly ripe mango. Juice running down your fingers. That unmistakable taste of sunshine. We bring you mangoes worth slowing down for.
            </p>
          </Reveal>
          <ul className="mt-10 grid gap-6 sm:grid-cols-3">
            {pillars.map((p, i) => (
              <Reveal as="li" key={p.title} delay={i * 110} className="rounded-3xl bg-cream p-5">
                <span className="grid h-12 w-12 place-items-center rounded-full bg-sun text-leaf"><FeatureIcon name={p.icon} /></span>
                <h3 className="mt-4 font-serif text-xl font-black leading-tight text-leaf">{p.title}</h3>
                <p className="mt-1.5 text-[15px] leading-relaxed text-leaf/80">{p.text}</p>
              </Reveal>
            ))}
          </ul>
        </div>
      </div>
    </section>
  )
}
