import { useState } from 'react'
import { useCart } from '../context/CartContext'
import { money } from '../lib/format'
import Quantity from './Quantity'
import ProductArt from './ProductArt'
import Reveal from './Reveal'
import { CheckIcon, PlusIcon } from './Icons'

export default function ProductCard({ product, index }) {
  const { add } = useCart()
  const [qty, setQty] = useState(1)
  const [added, setAdded] = useState(false)

  const onAdd = () => {
    add(product, qty)
    setAdded(true)
    setTimeout(() => setAdded(false), 1600)
    setQty(1)
  }

  return (
    <Reveal as="li" delay={index * 120} className={`group flex flex-col ${index === 1 ? 'md:mt-12' : ''}`}>
      <article aria-labelledby={`${product.id}-name`} className="flex h-full flex-col overflow-hidden rounded-[2rem] bg-ivory shadow-[0_2px_0_rgba(31,74,46,.08),0_24px_50px_-28px_rgba(31,74,46,.45)] transition duration-500 hover:-translate-y-2 hover:shadow-[0_2px_0_rgba(31,74,46,.08),0_40px_60px_-26px_rgba(31,74,46,.5)]">
        <div className="relative aspect-[4/5] overflow-hidden">
          <div className="h-full w-full transition-transform duration-700 ease-out group-hover:scale-[1.04]">
            <ProductArt product={product} />
          </div>
          <span className="absolute left-4 top-4 rounded-full bg-leaf px-3.5 py-1.5 text-[11px] font-bold uppercase tracking-[.16em] text-ivory">{product.badge}</span>
        </div>
        <div className="flex flex-1 flex-col p-6 sm:p-7">
          <h3 id={`${product.id}-name`} className="font-serif text-[1.7rem] font-black leading-tight text-leaf">{product.name}</h3>
          <p className="mt-2 text-base leading-relaxed text-leaf/80">{product.description}</p>
          <p className="mt-3 text-sm font-medium text-earth">{product.size}</p>
          <div className="mt-5 flex items-baseline gap-2">
            <span className="font-serif text-4xl font-black text-leaf">{money(product.price)}</span>
            <span className="text-sm font-medium text-leaf/70">{product.unit}</span>
          </div>
          <div className="mt-6 flex flex-wrap items-center gap-3">
            <Quantity value={qty} onChange={setQty} label={product.name} />
            <button type="button" onClick={onAdd} className={`btn min-w-0 flex-1 whitespace-nowrap !gap-2 !px-4 !tracking-[.08em] ${added ? 'btn-done' : 'btn-primary'}`}>
              {added ? <><CheckIcon className="h-5 w-5" /> Added</> : <><PlusIcon className="h-5 w-5" /> Add to cart</>}
            </button>
          </div>
        </div>
      </article>
    </Reveal>
  )
}
