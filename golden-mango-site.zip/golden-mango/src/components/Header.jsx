import { useEffect, useState } from 'react'
import { useCart } from '../context/CartContext'
import { BagIcon } from './Icons'
import { Sparkle } from './art/Primitives'

export function Logo({ className = '', light = false }) {
  return (
    <a href="#top" aria-label="GOLDEN MANGO – back to top" className={`group inline-flex items-center gap-1.5 whitespace-nowrap font-serif text-base font-black tracking-[.1em] sm:gap-2 sm:text-xl sm:tracking-[.14em] ${light ? 'text-ivory' : 'text-leaf'} ${className}`}>
      <Sparkle className="h-5 w-5 text-sun transition-transform duration-500 group-hover:rotate-90" />
      GOLDEN MANGO
    </a>
  )
}

export function AnnouncementBar() {
  return (
    <div className="bg-leaf px-4 py-2 text-center text-[11px] font-semibold uppercase tracking-[.22em] text-ivory sm:text-xs">
      Sunshine delivered to your door <span aria-hidden="true">☀️</span>
    </div>
  )
}

export default function Header() {
  const { count, setOpen, bump } = useCart()
  const [stuck, setStuck] = useState(false)
  useEffect(() => {
    const on = () => setStuck(window.scrollY > 8)
    on()
    window.addEventListener('scroll', on, { passive: true })
    return () => window.removeEventListener('scroll', on)
  }, [])
  const link = 'link-underline rounded px-1 py-2 text-sm font-semibold text-leaf sm:text-[15px]'
  return (
    <header className={`sticky top-0 z-40 transition-all duration-300 ${stuck ? 'bg-ivory/90 shadow-[0_1px_0_rgba(31,74,46,.12)] backdrop-blur-md' : 'bg-ivory'}`}>
      <nav aria-label="Main" className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-3 px-4 sm:h-[72px] sm:px-8">
        <Logo />
        <div className="flex items-center gap-3 sm:gap-8">
          <a href="#shop" className={link}>Shop<span className="hidden sm:inline"> Mangoes</span></a>
          <a href="#story" className={link}>Our<span className="hidden sm:inline"> Story</span></a>
          <button
            type="button" onClick={() => setOpen(true)}
            aria-label={`Open shopping bag, ${count} ${count === 1 ? 'item' : 'items'}`} aria-haspopup="dialog"
            className="relative grid h-11 w-11 place-items-center rounded-full bg-sun text-leaf transition hover:bg-amber"
          >
            <span key={bump} className={bump ? 'animate-bump' : ''}><BagIcon className="h-6 w-6" /></span>
            <span key={`c${count}`} className={`absolute -right-1 -top-1 grid h-5 min-w-5 place-items-center rounded-full bg-leaf px-1 text-[11px] font-bold text-ivory ${bump ? 'animate-pop' : ''}`} aria-hidden="true">{count}</span>
          </button>
        </div>
      </nav>
    </header>
  )
}
