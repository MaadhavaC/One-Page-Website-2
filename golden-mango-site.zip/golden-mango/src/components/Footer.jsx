import { site } from '../config/site'
import { Logo } from './Header'

export default function Footer({ onOpenPolicy }) {
  const h = 'text-xs font-bold uppercase tracking-[.2em] text-sun'
  const a = 'rounded py-1 text-ivory/85 transition hover:text-sun'
  return (
    <footer className="bg-forest px-4 pb-10 pt-16 text-ivory sm:px-8">
      <div className="mx-auto grid max-w-7xl gap-12 md:grid-cols-12">
        <div className="md:col-span-4">
          <Logo light />
          <p className="mt-4 max-w-xs text-ivory/80">Golden, juicy, ridiculously delicious mangoes. Sunshine delivered to your door.</p>
          <ul className="mt-5 flex flex-wrap gap-2" aria-label="Social media">
            {site.social.map((s) => (
              <li key={s.label}><a href={s.href} target="_blank" rel="noopener noreferrer" className="inline-block rounded-full border border-ivory/30 px-4 py-2 text-sm font-semibold transition hover:border-sun hover:bg-sun hover:text-leaf">{s.label}<span className="sr-only"> (opens in a new tab)</span></a></li>
            ))}
          </ul>
        </div>
        <nav aria-label="Footer" className="md:col-span-2">
          <h2 className={h}>Explore</h2>
          <ul className="mt-3 space-y-1">
            <li><a className={a} href="#shop">Shop Mangoes</a></li>
            <li><a className={a} href="#story">Our Story</a></li>
            <li><a className={a} href="#top">Back to top</a></li>
          </ul>
        </nav>
        <div className="md:col-span-3">
          <h2 className={h}>Contact</h2>
          <ul className="mt-3 space-y-1 text-ivory/85">
            <li><a className={a} href={`mailto:${site.contact.email}`}>{site.contact.email}</a></li>
            <li><a className={a} href={`tel:${site.contact.phone.replace(/[^+\d]/g, '')}`}>{site.contact.phone}</a></li>
            <li>{site.contact.hours}</li>
            <li>{site.contact.address}</li>
          </ul>
        </div>
        <div className="md:col-span-3">
          <h2 className={h}>Delivery information</h2>
          <p className="mt-3 text-ivory/85">{site.delivery.summary}</p>
          <p className="mt-2 text-sm text-ivory/65">{site.delivery.detail}</p>
        </div>
      </div>
      <div className="mx-auto mt-14 flex max-w-7xl flex-col gap-3 border-t border-ivory/15 pt-6 text-sm text-ivory/70 sm:flex-row sm:items-center sm:justify-between">
        <p>© {new Date().getFullYear()} {site.name}. All rights reserved.</p>
        <ul className="flex gap-5">
          <li><button type="button" onClick={() => onOpenPolicy('privacy')} className="rounded underline-offset-4 hover:text-sun hover:underline">Privacy Policy</button></li>
          <li><button type="button" onClick={() => onOpenPolicy('terms')} className="rounded underline-offset-4 hover:text-sun hover:underline">Terms &amp; Conditions</button></li>
        </ul>
      </div>
    </footer>
  )
}
