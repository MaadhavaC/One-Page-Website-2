import { useCart } from '../context/CartContext'
import { CheckIcon } from './Icons'

/** Item-added feedback. Polite live region so screen readers announce it. */
export default function Toast() {
  const { toast, setOpen, dismissToast } = useCart()
  return (
    <div aria-live="polite" className="pointer-events-none fixed inset-x-0 bottom-4 z-[70] flex justify-center px-4">
      {toast && (
        <div key={toast.key} className="pointer-events-auto flex max-w-md items-center gap-3 rounded-full bg-leaf py-2.5 pl-4 pr-2.5 text-ivory shadow-2xl animate-toastIn">
          <CheckIcon className="h-5 w-5 shrink-0 text-sun" />
          <p className="text-sm font-medium">{toast.message}</p>
          <button type="button" onClick={() => { dismissToast(); setOpen(true) }} className="shrink-0 rounded-full bg-sun px-4 py-2 text-sm font-bold text-leaf hover:bg-amber">View bag</button>
        </div>
      )}
    </div>
  )
}
