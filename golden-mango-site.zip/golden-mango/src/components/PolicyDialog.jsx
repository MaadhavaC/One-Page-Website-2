import { site } from '../config/site'
import { useDialog } from '../hooks/useDialog'
import { CloseIcon } from './Icons'

export default function PolicyDialog({ policy, onClose }) {
  const ref = useDialog(Boolean(policy), onClose)
  if (!policy) return null
  const p = site.policies[policy]
  return (
    <div className="fixed inset-0 z-[60] grid place-items-center p-4">
      <div className="absolute inset-0 bg-forest/70 backdrop-blur-sm" onClick={onClose} aria-hidden="true" />
      <div ref={ref} role="dialog" aria-modal="true" aria-labelledby="policy-title" className="relative max-h-[85vh] w-full max-w-lg overflow-auto rounded-[2rem] bg-ivory p-7 text-leaf shadow-2xl animate-toastIn sm:p-9">
        <button type="button" onClick={onClose} aria-label="Close" className="absolute right-4 top-4 grid h-10 w-10 place-items-center rounded-full hover:bg-cream"><CloseIcon className="h-5 w-5" /></button>
        <h2 id="policy-title" className="pr-10 font-serif text-3xl font-black">{p.title}</h2>
        <div className="mt-4 space-y-3 leading-relaxed text-leaf/85">{p.body.map((t, i) => <p key={i}>{t}</p>)}</div>
        <button type="button" data-autofocus onClick={onClose} className="btn btn-primary mt-7">Close</button>
      </div>
    </div>
  )
}
