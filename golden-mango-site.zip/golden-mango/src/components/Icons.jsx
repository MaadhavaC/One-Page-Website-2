const base = { viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 1.7, strokeLinecap: 'round', strokeLinejoin: 'round', 'aria-hidden': true, focusable: 'false' }

export const BagIcon = (p) => (<svg {...base} {...p}><path d="M5 8h14l-1 12H6L5 8Z" /><path d="M9 8V6.5a3 3 0 0 1 6 0V8" /></svg>)
export const CloseIcon = (p) => (<svg {...base} {...p}><path d="M6 6l12 12M18 6 6 18" /></svg>)
export const PlusIcon = (p) => (<svg {...base} {...p}><path d="M12 5v14M5 12h14" /></svg>)
export const MinusIcon = (p) => (<svg {...base} {...p}><path d="M5 12h14" /></svg>)
export const ArrowIcon = (p) => (<svg {...base} strokeWidth={2} {...p}><path d="M4 12h15M13 6l6 6-6 6" /></svg>)
export const CheckIcon = (p) => (<svg {...base} strokeWidth={2.2} {...p}><path d="m5 12.5 4.5 4.5L19 7.5" /></svg>)
export const TrashIcon = (p) => (<svg {...base} {...p}><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3" /></svg>)

export const Star = ({ filled = true, className = '' }) => (
  <svg viewBox="0 0 24 24" className={className} aria-hidden="true" focusable="false">
    <path d="m12 2.8 2.8 5.9 6.4.8-4.7 4.4 1.2 6.4L12 17.2 6.3 20.3l1.2-6.4L2.8 9.5l6.4-.8L12 2.8Z" fill={filled ? '#FFB400' : 'none'} stroke="#E28A00" strokeWidth="1.4" strokeLinejoin="round" />
  </svg>
)

const set = {
  flavour: <><path d="M12 21c-4.5 0-8-3.3-8-7.8C4 8 8 4.5 12 3c4 1.5 8 5 8 10.2 0 4.5-3.5 7.8-8 7.8Z" /><path d="M12 3c0 3-1.5 5-4 6" /></>,
  care: <><path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10Z" /></>,
  sun: <><circle cx="12" cy="12" r="4" /><path d="M12 2v2.5M12 19.5V22M2 12h2.5M19.5 12H22M4.9 4.9l1.8 1.8M17.3 17.3l1.8 1.8M19.1 4.9l-1.8 1.8M6.7 17.3l-1.8 1.8" /></>,
  select: <><path d="M5 12.5 9.5 17 19 7" /><circle cx="12" cy="12" r="10" /></>,
  lock: <><rect x="5" y="10.5" width="14" height="10" rx="2.5" /><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5M12 15v2" /></>,
  truck: <><path d="M2 6h11v10H2zM13 9.5h4.5L21 13v3h-8" /><circle cx="7" cy="17.5" r="2" /><circle cx="17" cy="17.5" r="2" /></>,
  support: <><path d="M4 13v-1a8 8 0 0 1 16 0v1" /><rect x="3" y="13" width="4" height="6" rx="1.5" /><rect x="17" y="13" width="4" height="6" rx="1.5" /><path d="M19 19c0 1.5-2 2-5 2" /></>,
}
export const FeatureIcon = ({ name, className = 'h-7 w-7' }) => (<svg {...base} className={className}>{set[name]}</svg>)
