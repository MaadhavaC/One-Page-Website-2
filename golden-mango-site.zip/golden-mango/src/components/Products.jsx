import { products } from '../data/products'
import ProductCard from './ProductCard'
import Reveal from './Reveal'

export default function Products() {
  return (
    <section id="shop" aria-labelledby="shop-title" className="scroll-mt-20 bg-cream px-4 py-20 sm:px-8 sm:py-28">
      <div className="mx-auto max-w-7xl">
        <Reveal className="mx-auto max-w-3xl text-center">
          <p className="eyebrow">The shop</p>
          <h2 id="shop-title" className="h-display">Meet your new <em className="text-flame not-italic">favourite</em> fruit.</h2>
        </Reveal>
        <ul className="mt-14 grid gap-8 sm:mt-16 md:grid-cols-3 md:items-start lg:gap-10">
          {products.map((p, i) => <ProductCard key={p.id} product={p} index={i} />)}
        </ul>
      </div>
    </section>
  )
}
