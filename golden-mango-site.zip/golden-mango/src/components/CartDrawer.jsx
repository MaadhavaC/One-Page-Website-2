import { useEffect, useState } from 'react'
import { useCart } from '../context/CartContext'
import { useDialog } from '../hooks/useDialog'
import { money } from '../lib/format'
import { getCheckoutUrl } from '../lib/checkout'
import Quantity from './Quantity'
import ProductArt from './ProductArt'
import { ArrowIcon, CloseIcon, TrashIcon, BagIcon } from './Icons'

export default function CartDrawer() {
  const { open, setOpen, lines, count, subtotal, setQty, clear } = useCart()
  const close = () => setOpen(false)
  const ref = useDialog(open, close)
  const [notice, setNotice] = useState(false)

  useEffect(() => { if (!open) setNotice(false) }, [open])
  useEffect(() => { if (!lines.length) setNotice(false) }, [lines.length])

  const checkout = () => {
    const url = getCheckoutUrl(lines)
    if (url) window.location.assign(url)
    else setNotice(true)
  }

  return (
    <div className={`fixed inset-0 z-50 ${open ? '' : 'pointer-events-none'}`} aria-hidden={!open}>
      <div onClick={close} className={`absolute inset-0 bg-forest/60 backdrop-blur-[2px] transition-opacity duration-300 ${open ? 'opacity-100' : 'opacity-0'}`} />
      <aside
        ref={ref} role="dialog" aria-modal="true" aria-labelledby="bag-title" inert={!open ? '' : undefined}
        className={`absolute inset-y-0 right-0 flex w-full max-w-md flex-col bg-ivory shadow-2xl transition-transform duration-500 ease-[cubic-bezier(.2,.8,.2,1)] ${open ? 'translate-x-0' : 'translate-x-full'}`}
      >
        <div className="flex items-center justify-between border-b border-leaf/10 px-6 py-5">
          <h2 id="bag-title" className="font-serif text-2xl font-black text-leaf">Your bag <span className="text-base font-semibold text-leaf/60">({count})</span></h2>
          <button type="button" onClick={close} aria-label="Close shopping bag" className="grid h-11 w-11 place-items-center rounded-full text-leaf hover:bg-cream"><CloseIcon className="h-6 w-6" /></button>
        </div>

        {lines.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center px-8 text-center">
            <span className="grid h-20 w-20 place-items-center rounded-full bg-cream text-leaf"><BagIcon className="h-9 w-9" /></span>
            <p className="mt-5 font-serif text-2xl font-black text-leaf">Your bag is empty</p>
            <p className="mt-2 text-leaf/75">Let’s fix that. Some sunshine is waiting for you.</p>
            <a href="#shop" onClick={close} className="btn btn-primary mt-7">Shop mangoes <ArrowIcon className="btn-arrow h-5 w-5" /></a>
          </div>
        ) : (
          <>
            <ul className="flex-1 divide-y divide-leaf/10 overflow-y-auto px-6">
              {lines.map(({ product, qty }) => (
                <li key={product.id} className="flex gap-4 py-5">
                  <div className="h-24 w-20 shrink-0 overflow-hidden rounded-2xl"><ProductArt product={product} /></div>
                  <div className="flex min-w-0 flex-1 flex-col">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h3 className="font-serif text-lg font-black leading-tight text-leaf">{product.name}</h3>
                        <p className="text-sm text-leaf/70">{money(product.price)} {product.unit}</p>
                      </div>
                      <button type="button" onClick={() => setQty(product.id, 0)} aria-label={`Remove ${product.name} from bag`} className="grid h-9 w-9 shrink-0 place-items-center rounded-full text-leaf/70 hover:bg-cream hover:text-leaf"><TrashIcon className="h-5 w-5" /></button>
                    </div>
                    <div className="mt-auto flex items-center justify-between pt-3">
                      <Quantity compact value={qty} label={product.name} onChange={(n) => setQty(product.id, n)} onBelowMin={() => setQty(product.id, 0)} />
                      <p className="font-semibold tabular-nums text-leaf">{money(product.price * qty)}</p>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
            <div className="border-t border-leaf/10 bg-cream/60 px-6 py-5">
              <div className="flex items-baseline justify-between">
                <span className="font-semibold text-leaf">Subtotal</span>
                <span className="font-serif text-3xl font-black tabular-nums text-leaf" aria-live="polite">{money(subtotal)}</span>
              </div>
              <p className="mt-1 text-sm text-leaf/70">Delivery and any taxes are calculated at checkout.</p>
              <button type="button" onClick={checkout} className="btn btn-primary mt-4 w-full">Checkout · {money(subtotal)} <ArrowIcon className="btn-arrow h-5 w-5" /></button>
              {notice && (
                <div role="status" className="mt-4 rounded-2xl border-2 border-dashed border-ember/50 bg-ivory p-4 text-sm leading-relaxed text-leaf">
                  <strong className="text-ember">Checkout isn’t connected yet.</strong> No payment has been taken and no order has been placed. Connect Shopify, Stripe or another provider in <code className="rounded bg-cream px-1">src/config/site.js</code> to enable real checkout.
                </div>
              )}
              <button type="button" onClick={clear} className="mx-auto mt-3 block rounded px-2 py-1 text-sm font-semibold text-leaf/70 underline underline-offset-4 hover:text-leaf">Empty bag</button>
            </div>
          </>
        )}
      </aside>
    </div>
  )
}
