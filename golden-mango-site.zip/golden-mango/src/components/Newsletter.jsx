import { useId, useState } from 'react'
import { site } from '../config/site'
import { ArrowIcon, CheckIcon } from './Icons'
import Reveal from './Reveal'

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/

export default function Newsletter({ onOpenPolicy }) {
  const uid = useId()
  const [email, setEmail] = useState('')
  const [consent, setConsent] = useState(false)
  const [errors, setErrors] = useState({})
  const [status, setStatus] = useState('idle') // idle | sending | done | unconnected | failed

  const validate = () => {
    const e = {}
    if (!email.trim()) e.email = 'Please enter your email address.'
    else if (!EMAIL.test(email.trim())) e.email = 'That email address doesn’t look right. Please check it and try again.'
    if (!consent) e.consent = 'Please tick the box to agree before subscribing.'
    return e
  }

  const submit = async (ev) => {
    ev.preventDefault()
    const e = validate()
    setErrors(e)
    if (Object.keys(e).length) return
    if (!site.newsletter.endpoint) { setStatus('unconnected'); return }
    setStatus('sending')
    try {
      const res = await fetch(site.newsletter.endpoint, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim(), consent: true, source: 'golden-mango-site' }),
      })
      if (!res.ok) throw new Error(String(res.status))
      setStatus('done')
    } catch {
      setStatus('failed')
    }
  }

  const field = 'w-full rounded-full border-2 bg-ivory px-6 py-4 text-base text-leaf placeholder:text-leaf/55'
  return (
    <section aria-labelledby="news-title" className="bg-leaf px-4 py-20 text-ivory sm:px-8 sm:py-24">
      <Reveal className="mx-auto max-w-3xl text-center">
        <h2 id="news-title" className="font-serif text-[clamp(2.2rem,8vw,4rem)] font-black uppercase leading-[.95] tracking-tight">Good things are <span className="text-sun">ripening.</span></h2>
        <p className="mx-auto mt-5 max-w-xl text-lg text-ivory/85">Get seasonal updates, delicious inspiration, and first dibs on our mango boxes.</p>

        {status === 'done' ? (
          <p role="status" className="mx-auto mt-9 flex max-w-md items-center justify-center gap-3 rounded-full bg-sun px-6 py-4 font-semibold text-leaf">
            <CheckIcon className="h-6 w-6 shrink-0" /> You’re on the list. Thank you!
          </p>
        ) : (
          <form onSubmit={submit} noValidate className="mx-auto mt-9 max-w-xl text-left">
            <div className="flex flex-col gap-3 sm:flex-row">
              <div className="flex-1">
                <label htmlFor={`${uid}e`} className="sr-only">Email address</label>
                <input
                  id={`${uid}e`} type="email" name="email" autoComplete="email" inputMode="email" placeholder="Your email address"
                  value={email} onChange={(e) => { setEmail(e.target.value); if (errors.email) setErrors({ ...errors, email: undefined }) }}
                  aria-invalid={errors.email ? 'true' : 'false'} aria-describedby={errors.email ? `${uid}ee` : undefined}
                  className={`${field} ${errors.email ? 'border-[#FF8A6B]' : 'border-transparent'}`}
                />
              </div>
              <button type="submit" disabled={status === 'sending'} className="btn btn-sun shrink-0">
                {status === 'sending' ? 'Sending…' : <>Subscribe <ArrowIcon className="btn-arrow h-5 w-5" /></>}
              </button>
            </div>
            {errors.email && <p id={`${uid}ee`} role="alert" className="mt-2 pl-4 text-sm font-medium text-[#FFB9A6]">{errors.email}</p>}

            <div className="mt-4 flex items-start gap-3 pl-1">
              <input
                id={`${uid}c`} type="checkbox" checked={consent} onChange={(e) => { setConsent(e.target.checked); if (errors.consent) setErrors({ ...errors, consent: undefined }) }}
                aria-invalid={errors.consent ? 'true' : 'false'} aria-describedby={errors.consent ? `${uid}ce` : undefined}
                className="mt-1 h-5 w-5 shrink-0 accent-sun"
              />
              <label htmlFor={`${uid}c`} className="text-sm leading-relaxed text-ivory/85">
                I agree to receive GOLDEN MANGO emails about seasonal updates, recipes and offers. I can unsubscribe at any time. See our{' '}
                <button type="button" onClick={() => onOpenPolicy('privacy')} className="font-semibold text-sun underline underline-offset-2">Privacy Policy</button>.
              </label>
            </div>
            {errors.consent && <p id={`${uid}ce`} role="alert" className="mt-2 pl-9 text-sm font-medium text-[#FFB9A6]">{errors.consent}</p>}

            {status === 'unconnected' && (
              <p role="status" className="mt-5 rounded-2xl border border-sun/60 bg-forest/60 p-4 text-sm leading-relaxed text-ivory">
                <strong className="text-sun">Newsletter not connected yet.</strong> Your details look valid, but no email service is set up, so nothing has been saved or sent. Set <code className="rounded bg-black/30 px-1">newsletter.endpoint</code> in <code className="rounded bg-black/30 px-1">src/config/site.js</code> to go live.
              </p>
            )}
            {status === 'failed' && <p role="alert" className="mt-5 text-sm font-medium text-[#FFB9A6]">Sorry, we couldn’t sign you up just now. Please try again in a moment.</p>}
          </form>
        )}
      </Reveal>
    </section>
  )
}
