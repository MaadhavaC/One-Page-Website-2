import { site } from '../config/site'
import { lifestyle } from '../data/content'
import { BowlScene, Photo, PlateScene, SmoothieScene } from './art/Scenes'
import Reveal from './Reveal'

const SCENES = { lifestylePlate: PlateScene, lifestyleSmoothie: SmoothieScene, lifestyleBowl: BowlScene }
// Asymmetric editorial grid (desktop): tall centre, offset sides.
const LAYOUT = ['md:col-span-5 aspect-[4/5] md:mt-16', 'md:col-span-4 aspect-[3/5]', 'md:col-span-3 aspect-[3/4] md:mt-32']

export default function Lifestyle() {
  return (
    <section aria-labelledby="life-title" className="overflow-hidden bg-cream px-4 py-20 sm:px-8 sm:py-28">
      <div className="mx-auto max-w-7xl">
        <Reveal className="max-w-3xl">
          <p className="eyebrow">Taste the moment</p>
          <h2 id="life-title" className="h-display">Life is sweeter with <em className="text-flame not-italic">mangoes.</em></h2>
        </Reveal>
        <ul className="mt-12 grid gap-6 md:grid-cols-12 md:items-start md:gap-7">
          {lifestyle.map((item, i) => {
            const Scene = SCENES[item.slot]
            return (
              <Reveal as="li" key={item.slot} delay={i * 130} className={`group relative overflow-hidden rounded-[2rem] ${LAYOUT[i]}`}>
                <div className="h-full w-full transition-transform duration-700 ease-out group-hover:scale-[1.05]">
                  <Photo src={site.images[item.slot]} alt={item.alt}><Scene /></Photo>
                </div>
                <p className="absolute inset-x-4 bottom-4 rounded-full bg-ivory/95 px-5 py-3 text-center font-serif text-lg font-black text-leaf backdrop-blur sm:text-xl">{item.caption}</p>
              </Reveal>
            )
          })}
        </ul>
      </div>
    </section>
  )
}
