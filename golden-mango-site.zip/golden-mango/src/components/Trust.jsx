import { trust } from '../data/content'
import { FeatureIcon } from './Icons'
import Reveal from './Reveal'

export default function Trust() {
  return (
    <section aria-labelledby="trust-title" className="bg-ivory px-4 py-16 sm:px-8 sm:py-20">
      <div className="mx-auto max-w-7xl">
        <h2 id="trust-title" className="sr-only">Why customers will love us</h2>
        <ul className="grid gap-x-8 gap-y-10 sm:grid-cols-2 lg:grid-cols-4">
          {trust.map((t, i) => (
            <Reveal as="li" key={t.title} delay={i * 90} className="flex gap-4 lg:block">
              <span className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl border-2 border-leaf/15 bg-cream text-leaf"><FeatureIcon name={t.icon} className="h-7 w-7" /></span>
              <div>
                <h3 className="font-serif text-xl font-black text-leaf lg:mt-4">{t.title}</h3>
                <p className="mt-1.5 text-[15px] leading-relaxed text-leaf/80">{t.text}</p>
              </div>
            </Reveal>
          ))}
        </ul>
      </div>
    </section>
  )
}
