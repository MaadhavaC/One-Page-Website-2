import { createContext, useCallback, useContext, useEffect, useMemo, useReducer, useRef, useState } from 'react'
import { getProduct } from '../data/products'
import { money } from '../lib/format'

const KEY = 'golden-mango-cart-v1'
const MAX = 99
const CartContext = createContext(null)

function reducer(state, a) {
  switch (a.type) {
    case 'add':
      return { ...state, [a.id]: Math.min(MAX, (state[a.id] || 0) + a.qty) }
    case 'set': {
      if (a.qty <= 0) {
        const { [a.id]: _removed, ...rest } = state
        return rest
      }
      return { ...state, [a.id]: Math.min(MAX, a.qty) }
    }
    case 'clear':
      return {}
    default:
      return state
  }
}

function load() {
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) || '{}')
    return Object.fromEntries(
      Object.entries(raw).filter(([id, q]) => getProduct(id) && Number.isInteger(q) && q > 0).map(([id, q]) => [id, Math.min(q, MAX)]),
    )
  } catch {
    return {}
  }
}

export function CartProvider({ children }) {
  const [items, dispatch] = useReducer(reducer, undefined, load)
  const [open, setOpen] = useState(false)
  const [bump, setBump] = useState(0)
  const [toast, setToast] = useState(null)
  const timer = useRef()

  useEffect(() => {
    try { localStorage.setItem(KEY, JSON.stringify(items)) } catch { /* storage unavailable */ }
  }, [items])

  const lines = useMemo(
    () => Object.entries(items).map(([id, qty]) => ({ product: getProduct(id), qty })).filter((l) => l.product),
    [items],
  )
  const count = lines.reduce((n, l) => n + l.qty, 0)
  const subtotal = lines.reduce((n, l) => n + l.qty * l.product.price, 0)

  const add = useCallback((product, qty = 1) => {
    dispatch({ type: 'add', id: product.id, qty })
    setBump((b) => b + 1)
    setToast({ key: Date.now(), message: `${qty} × ${product.name} added to your bag`, total: money(qty * product.price) })
    clearTimeout(timer.current)
    timer.current = setTimeout(() => setToast(null), 4000)
  }, [])
  const setQty = useCallback((id, qty) => dispatch({ type: 'set', id, qty }), [])
  const clear = useCallback(() => dispatch({ type: 'clear' }), [])
  const dismissToast = useCallback(() => setToast(null), [])

  const value = { lines, count, subtotal, add, setQty, clear, open, setOpen, bump, toast, dismissToast }
  return <CartContext.Provider value={value}>{children}</CartContext.Provider>
}

export const useCart = () => useContext(CartContext)
