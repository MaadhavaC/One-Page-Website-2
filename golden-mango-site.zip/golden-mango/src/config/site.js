// ─────────────────────────────────────────────────────────────
// GOLDEN MANGO – editable site configuration.
// Everything marked "placeholder" must be confirmed before launch.
// ─────────────────────────────────────────────────────────────

export const site = {
  name: 'GOLDEN MANGO',
  currency: 'GBP',
  locale: 'en-GB',

  // Contact details – PLACEHOLDERS (reserved example domain / dummy number)
  contact: {
    email: 'hello@goldenmango.example',
    phone: '+44 (0)00 0000 0000',
    address: 'Your business address here',
    hours: 'Mon–Fri, 9am–5pm',
  },

  // Social links – point these at your real profiles.
  social: [
    { label: 'Instagram', href: 'https://www.instagram.com/' },
    { label: 'TikTok', href: 'https://www.tiktok.com/' },
    { label: 'Facebook', href: 'https://www.facebook.com/' },
  ],

  // Delivery copy – PLACEHOLDER. Only publish timings/areas you can honour.
  delivery: {
    summary: 'Delivery options and timings are shown at checkout.',
    detail:
      'We will confirm delivery areas, timings and costs here before launch. Add your own delivery policy text in src/config/site.js.',
  },

  // Policy copy shown in the footer dialogs – PLACEHOLDER, replace with real policies.
  policies: {
    privacy: {
      title: 'Privacy Policy',
      body: [
        'This is a placeholder. Replace this text with your privacy policy before launch.',
        'It should explain what personal data you collect (for example email addresses and delivery details), why you collect it, how long you keep it and how people can contact you to exercise their rights.',
      ],
    },
    terms: {
      title: 'Terms & Conditions',
      body: [
        'This is a placeholder. Replace this text with your terms and conditions before launch.',
        'It should cover ordering, pricing, delivery, returns and refunds, and your contact details.',
      ],
    },
  },

  // ── Checkout integration ─────────────────────────────────────
  // Nothing is charged and no order is created unless you connect a provider.
  //   provider: 'none'     → shows an honest "not connected" notice (default)
  //   provider: 'shopify'  → redirects to https://<storeDomain>/cart/<variantId>:<qty>,…
  //                          (fill `variantId` on each product in src/data/products.js)
  //   provider: 'url'      → redirects to `url`; the cart is passed as ?items=<id>:<qty>,…
  //                          (point it at your own checkout / Stripe Checkout session endpoint)
  checkout: {
    provider: 'none',
    storeDomain: '', // e.g. 'goldenmango.myshopify.com'
    url: '',
  },

  // ── Newsletter integration ───────────────────────────────────
  // Set `endpoint` to a URL that accepts POST JSON {email, consent, source}
  // (Mailchimp/Klaviyo/ConvertKit proxy, serverless function, etc.).
  // While empty, the form validates but clearly reports it is not connected.
  newsletter: { endpoint: '' },

  // ── Photography slots ────────────────────────────────────────
  // Every picture on the page is a slot. Drop real photos in /public/images and
  // set the path (e.g. '/images/hero.jpg') to replace the built-in artwork.
  images: {
    hero: null,
    classic: null,
    tropical: null,
    box: null,
    story: null,
    lifestylePlate: null,
    lifestyleSmoothie: null,
    lifestyleBowl: null,
    finale: null,
  },
}
