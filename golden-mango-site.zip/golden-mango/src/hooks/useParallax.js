import { useEffect } from 'react'

/** Pointer + scroll parallax for [data-parallax] roots. Skipped for reduced-motion and touch. */
export function useParallax() {
  useEffect(() => {
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)')
    const root = document.querySelector('[data-parallax]')
    if (!root || reduce.matches) return undefined
    let mx = 0, my = 0, sy = 0, raf = 0
    const paint = () => {
      raf = 0
      root.style.setProperty('--mx', mx.toFixed(3))
      root.style.setProperty('--my', my.toFixed(3))
      root.style.setProperty('--sy', sy.toFixed(3))
    }
    const queue = () => { if (!raf) raf = requestAnimationFrame(paint) }
    const onMove = (e) => {
      mx = (e.clientX / window.innerWidth - 0.5) * 2
      my = (e.clientY / window.innerHeight - 0.5) * 2
      queue()
    }
    const onScroll = () => { sy = Math.min(window.scrollY, window.innerHeight) / window.innerHeight; queue() }
    const fine = window.matchMedia('(pointer: fine)').matches
    if (fine) window.addEventListener('pointermove', onMove, { passive: true })
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => {
      window.removeEventListener('pointermove', onMove)
      window.removeEventListener('scroll', onScroll)
      cancelAnimationFrame(raf)
    }
  }, [])
}
