/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ivory: '#FFF9EC',
        cream: '#FBEFCF',
        sand: '#EADBB8',
        sun: '#FFC21A',
        amber: '#FF9A1F',
        flame: '#F26B1D',
        ember: '#A93E08', // orange dark enough for small text on ivory
        leaf: '#1F4A2E',
        forest: '#133120',
        moss: '#5E7F3C',
        earth: '#8A5A2B',
      },
      fontFamily: {
        serif: ['"Fraunces Variable"', 'Georgia', 'serif'],
        sans: ['"DM Sans Variable"', 'system-ui', 'sans-serif'],
      },
      keyframes: {
        float: { '0%,100%': { transform: 'translateY(0) rotate(0deg)' }, '50%': { transform: 'translateY(-14px) rotate(1.5deg)' } },
        bump: { '0%': { transform: 'scale(1) rotate(0)' }, '30%': { transform: 'scale(1.35) rotate(-14deg)' }, '60%': { transform: 'scale(.92) rotate(8deg)' }, '100%': { transform: 'scale(1) rotate(0)' } },
        pop: { '0%': { transform: 'scale(.4)' }, '60%': { transform: 'scale(1.3)' }, '100%': { transform: 'scale(1)' } },
        marquee: { to: { transform: 'translateX(-50%)' } },
        toastIn: { from: { opacity: 0, transform: 'translateY(16px) scale(.98)' }, to: { opacity: 1, transform: 'none' } },
      },
      animation: {
        float: 'float 7s ease-in-out infinite',
        bump: 'bump .6s ease',
        pop: 'pop .35s ease',
        marquee: 'marquee 38s linear infinite',
        toastIn: 'toastIn .35s cubic-bezier(.2,.8,.2,1)',
      },
    },
  },
  plugins: [],
}
