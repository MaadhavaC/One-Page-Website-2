# GOLDEN MANGO – one-page store (React + Tailwind + Vite)

    npm install
    npm run dev       # local dev server
    npm run build     # production build in /dist

## Edit without touching components
- `src/data/products.js` – products, GBP prices (pence), weights, badges, Shopify `variantId` / Stripe `stripePriceId` slots
- `src/config/site.js` – contact details, social links, delivery/policy copy, **checkout** and **newsletter** integration, photo slots
- `src/data/content.js` – pillars, trust points, **sample** reviews, lifestyle captions

## Going live checklist
1. **Photography** – the imagery is hand-built SVG artwork. Put real photos in `public/images/` and set the paths in `site.images`; each slot swaps in a lazy-loaded `<img>`.
2. **Checkout** – `site.checkout.provider` is `'none'`, so the Checkout button shows an honest "not connected" notice (no fake orders). Use `'shopify'` or `'url'` (e.g. a Stripe Checkout endpoint) – see `src/lib/checkout.js`.
3. **Newsletter** – set `site.newsletter.endpoint` (POST JSON `{email, consent, source}`).
4. Replace placeholder prices, weights, delivery/guarantee wording, contact details, policies and the sample reviews with confirmed facts.
